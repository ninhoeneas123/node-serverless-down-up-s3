
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'joseeneas',
  applicationName: 'serverless-s3',
  appUid: '82KBJQW9XdMZbys0cC',
  orgUid: 'df8fb6d2-9f3d-4119-a11d-654f1ec0e9f2',
  deploymentUid: '5dc8ce7e-6926-4580-8903-e2c46eaa03a4',
  serviceName: 's3-post-and-list-objects',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'user',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 's3-post-and-list-objects-user-listObjects', timeout: 6 };

try {
  const userHandler = require('./src/user/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.test, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}
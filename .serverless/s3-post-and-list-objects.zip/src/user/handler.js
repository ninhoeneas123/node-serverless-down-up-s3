export const test = () => {
    return "test";
};
//# sourceMappingURL=handler.js.map
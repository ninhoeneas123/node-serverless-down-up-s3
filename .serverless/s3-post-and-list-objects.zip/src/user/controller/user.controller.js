import AwsS3 from '../../aws/config-s3';
import https from 'https';
import fs from 'fs';
class UserController {
    async uploadFile(req, res) {
        const { path, originalname } = req.file;
        const blob = fs.readFileSync(path);
        await AwsS3.uploadFile(blob, originalname);
        return res.status(200).json({ message: 'Upload realizado com sucesso !' });
    }
    async getFile(req, res) {
        const { fileName } = req.params;
        const url = await AwsS3.getFile(fileName);
        https.get(url, (response) => {
            if (response.statusCode === 200) {
                res.setHeader('Content-Type', 'image/jpeg');
                res.setHeader('Content-Disposition', 'attachment; filename="imagem.jpg"');
                response.pipe(res);
            }
            else {
                res.statusCode = response.statusCode;
                res.end('Erro ao baixar o arquivo');
            }
        }).on('error', (error) => {
            console.error('Erro na solicitação:', error.message);
            res.statusCode = 500;
            res.end('Erro interno do servidor');
        });
    }
    async teste(req, res) {
        res.status(200).json({ message: 'Teste !' });
    }
}
export default new UserController;
//# sourceMappingURL=user.controller.js.map
import { S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
class AwsS3 {
    constructor() {
        this.clientS3 = new S3Client({
            region: 'us-east-1',
            credentials: {
                accessKeyId: 'AKIAWWKYOVSUNBRDOBEQ',
                secretAccessKey: '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',
            }
        });
    }
    async uploadFile(file, fileName) {
        const params = {
            Bucket: 'serveless-project',
            Key: fileName,
            Body: file,
        };
        const command = new PutObjectCommand(params);
        const data = await this.clientS3.send(command);
        return data;
    }
    async getFile(fileName) {
        const command = new GetObjectCommand({
            Bucket: 'serveless-project',
            Key: "Captura de tela de 2023-08-09 09-39-21.png",
        });
        const signedUrl = await getSignedUrl(this.clientS3, command, { expiresIn: 3600 }); // URL assinado válido por 1 hora
        return signedUrl;
    }
}
export default new AwsS3();
//# sourceMappingURL=config-s3.js.map